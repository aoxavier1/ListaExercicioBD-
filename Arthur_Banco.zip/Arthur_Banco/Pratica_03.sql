/* Questão 3 */

DELIMITER $$ 
create procedure Total_Clientes(out codigocliente int)
begin

Select * from cliente
order by nomecliente;

END$$
DELIMITER ;

CALL Total_Clientes(@a);

/* Questão 4 */

DELIMITER $$ 
create procedure prx_Produtos(inout codigoproduto integer)
begin

select * from produto
where precounitario < 3.50;

END$$
DELIMITER ;


set @valor = 3.00;
CALL prx_Produtos(@valor);

/* Questão 5 */

DELIMITER $$ 
create procedure prx_vendas(inout codigoproduto integer)
begin

select * from produto
where precounitario < 3.50;

END$$
DELIMITER ;


call prx_vendas(@valor);

/* Questão 6 */

DELIMITER $$ 
create procedure prx_produto
(p_codigoproduto integer, p_unidade character(2), p_descricaoproduto varchar(20), p_precounitario real )

main: BEGIN

if (p_codigoproduto = '') then
select 'ERRO: o campo nao pode ficar vazio' as msg;

leave main;

end if;
 
 if(p_unidade = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if;
 
 if (p_descricaoproduto = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if; 
 
 if (p_precounitario = '') then
 select 'ERRO: o campo nao pode ficar vazio' as msg;
 leave main;
 end if;
 
 insert into produto (codigoproduto, unidade, descricaoproduto, precounitario ) values (p_codigoproduto, p_unidade, p_descricaoproduto, p_precounitario);
 

END$$
DELIMITER ; 

 /* Call */
 
CALL prx_produto('58','23','','2.19');
 
 /* Select da tabela */
 
select * from produto;

 /* Questão 7 */
 
call prx_produto('58','kg','Arroz','2.19');
call prx_produto('50','M','Fralda','5.05');
call prx_produto('10','','','1.19');
