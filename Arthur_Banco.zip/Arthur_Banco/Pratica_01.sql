create schema banco;

use banco;

create table banco (
codigo varchar (30),
nome varchar(50) not null,
primary key (codigo)
);

/* Tabela de Banco */ 

create table agencia (
cod_banco int(10) ,
numero_ag varchar(25) not null,
endereco varchar(100) not null,
primary key (cod_banco),
foreign key	(cod_banco) references banco(codigo)
);

/* Tabela de Agencia */

create table cliente (
cpf varchar (20) not null,
nome varchar(50) not null,
sexo varchar(15) not null,
endereco varchar(100) not null,
primary key (cpf)
);


/* Tabela de Clientes */

create table conta (
numero_conta varchar (50) ,
saldo double not null,
tipo_conta varchar(60) not null,
num_agencia varchar (30) not null,
primary key (numero_conta),
foreign key	(num_agencia) references agencia(numero_agencia)
);
 
/* Tabela de Conta */

create table historico (
cpf_cliente varchar (30) not null,
num_conta varchar (30) not null,
data_inicio date not null,
primary key	(cpf_cliente),
foreign key	(cpf_cliente) references cliente(cpf),
foreign key	(num_conta) references	conta(numero_conta)
);


/* Tablea de Historico */

create table telefone_cliente (
cpf_cli varchar (30),
telefone varchar (16) not null,
primary key (cpf_cli),
foreign key	(cpf_cli) references	cliente(cpf)
);

/* Tablea de Telefone dos Clientes */ 

insert into banco (`codigo`,`nome`) values('1','Banco_do_Brasil');
insert into banco (`codigo`,`nome`) values('4','CEF');

insert	into agencia (`numero_ag`,`endereco,cod_banco`) values ('0562','Rua Joaquim Teixeira Alves, 1555','4');
insert	into agencia (`numero_ag,endereco`,`cod_banco`) values ('3153','Av. Marcelino Pires, 1960','1');

INSERT INTO cliente (`cpf`, `nome`, `sexo`, `endereco`) VALUES ('111.222.333-44', 'JenniferBSouza', 'F', 'RuaCuiabá,1050');
INSERT INTO cliente (`cpf`, `nome`, `sexo`, `endereco`) VALUES ('666.777.888-99', 'CaetanoKLima', 'M', 'RuaIvinhema,879');
INSERT INTO cliente (`cpf`, `nome`, `sexo`, `endereco`) VALUES ('555.444.777-33', 'SilviaMacedo', 'F', 'RuaEstadosUnidos,735');

INSERT INTO conta (`numero_conta`, `saldo`, `tipo_conta`, `num_agencia`) VALUES ('86340-2', '763.05', '2', '3153');
INSERT INTO conta (`numero_conta`, `saldo`, `tipo_conta`, `num_agencia`) VALUES ('23584-7', '3879.12', '1', '0562');

INSERT INTO historico (`cpf_cliente`, `num_conta`, `data_inicio`) VALUES ('111.222.333-44', '23584-7', '1997-12-17');
INSERT INTO historico (`cpf_cliente`, `num_conta`, `data_inicio`) VALUES ('666.777.888-99', '23584-7', '1997-12-17');
INSERT INTO historico (`cpf_cliente`, `num_conta`, `data_inicio`) VALUES ('555.444.777-33', '86340-2', '2010-11-29');

INSERT INTO telefone_cliente (`cpf_cli`, `telefone`) VALUES ('111.222.333-44', '(67)3422-7788');
INSERT INTO telefone_cliente (`cpf_cli`, `telefone`) VALUES ('666.777.888-99', '(67)3423-9900');
INSERT INTO telefone_cliente (`cpf_cli`, `telefone`) VALUES ('666.777.888-99', '(67)8121-8833');

/* Questão 4 */
alter table cliente add email varchar(30) after endereco;

select * from cliente;

/* Questão 5 */
SELECT cpf , endereco , nome FROM cliente WHERE nome = 'Paulo A Lima';

/* Questão 6 */ 
select numero_ag, endereco, cod_banco from agencia
where cod_banco='1'
order by numero_ag;

/* Questão 7 */ 
select numero_conta, num_agencia, nome
from cliente 
inner join conta;

/* Questão 8 */ 
select * from cliente 
where sexo= 'm'
order by nome;

/* Questão 9 */
select * from agencia , banco
where numero_agencia = '562';

/* Questão 10*/ 
delete from conta
where numero_conta = '86340.2';

select * from agencia;

/* Questão 11 */
UPDATE agencia 
SET numero_agencia = 6342
where cod_banco = 4;

select * from agencia;

/* Questão 12 */
update cliente set email = 'caetanolima@gmail.com' where cpf = '666.777.888-99';
 
select * from cliente;

/* Questão 13 */ 

select numero_conta, floor(saldo* 10/100)as 'Valor do Aumento de 10%' from conta;