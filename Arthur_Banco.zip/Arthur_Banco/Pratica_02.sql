/* Questão 3 */

create view estudantes_portugues as select nome, matricula
from estudante as es   inner join  cursa as c 
on (c.matricula_est = es.matricula)
where c.cod_disc = '2';

/* Questão 4 */  

select * from estudantes_portugues;

/* Questão 5 */ 

create table log_funcionario(
cpf_func varchar(15) null,
comando varchar (15) NULL,
usuario varchar (20)NULL,
data_hora date
);

/* Questão 6*/ 

DELIMITER $$
USE `Lista2`$$
CREATE DEFINER = CURRENT_USER TRIGGER `Lista2`.`tg_funcionario_UPDATE` AFTER UPDATE ON funcionario FOR EACH ROW
BEGIN
INSERT INTO log_funcionario
SET comando = 'UPDATE',
cpf_func = OLD.cpf,
usuario = CURRENT_USER,
data_hora= now();
END$$
estudanteDELIMITER ;

/* Questão 7 */ 

update funcionario set nome = 'Ronaldo Perreira' where cpf= '400289224' ;

select * from log_funcionario;

/* Questão 8 */ 

DELIMITER $$
USE `Lista2`$$
create definer = current_user trigger `Lista2`.`log_funcionario_INSERT` before insert on funcionario for each row
BEGIN
insert into log_funcionario
SET comando = 'INSERT',
cpf_func = new.cpf_func,
usuario = current_user,
data_hora = now();
END$$
DELIMITER ;

/* Questão 9 */ 

INSERT INTO funcionario VALUES ('12345678', 'Motorista', 'Arthur Oliveira', 'Chamequin ', '(61) 4002-85447', '1992-11-29', '2010-01-10', '3000');

select * from log_funcionario;






